#include <iostream>
#include <cstdio>
#include <ncurses.h>
#include <vector>
#include <string>
#include <fstream> //file stream
#include <unistd.h> //sleep

using namespace std;

int main(int argc, char *argv[])
{
    //initialise vars
    string word;
    vector<string> word_vector;
    //switch on what level they are on
    //read file 1
    fstream file;
    try
    {
        file.open("word_list_1.txt");
        while(file >> word)
        {
            //cout<< word <<endl;
            word_vector.push_back(word);
        }
        file.close();
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    cout << word_vector.size() << endl;
    return 0;
}