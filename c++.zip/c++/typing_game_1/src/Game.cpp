#include "Word.cpp"
#include <ncurses.h>
#include <vector>
#include <unistd.h>//sleep
#include <fstream>//fstream
#include <iostream>

class Game {
  private: 
    bool game_over;
    int game_win_height;
    int game_win_width;
    int info_win_height;
    int info_win_width;
    WINDOW *win_game;
    WINDOW *win_info;
    const int& increment = 1;

  public:
    Game();
    ~Game();
    void setup();
    std::vector<Word> read_file(int i);
    void start();
};

//const
Game::~Game() { endwin(); delwin(win_info);delwin(win_game);}
//de
Game::Game() {
  initscr();
  refresh();
  setup();
  refresh();
}

//ncurses setup
void Game::setup()
{
  // get max x and y
  int max_y, max_x = 10;
  getmaxyx(stdscr, max_y, max_x);
  // apply window height vars
  game_win_height = max_y * 0.75;
  game_win_width = max_x;
  info_win_height = max_y * 0.25;
  info_win_width = max_x;
  // create windows
  win_game = newwin(game_win_height, game_win_width, 0, 0);
  refresh();
  box(win_game, 0, 0);
  win_info = newwin(info_win_height, info_win_width, game_win_height + 1, 0);
  refresh();
  box(win_info, 0, 0);
  refresh();
  //wprintw(win_info, "HI");
  wrefresh(win_info);
  wrefresh(win_game);
}

//read words from file
std::vector<Word> Game:: read_file(int level)
{
  //initialise vars
  string word;
  vector<Word> word_vector;
  //switch on what level they are on
  //read file 1
  fstream file;
  try
  {
      file.open("word_list_1.txt");
      while(file >> word)
      {
          //cout<< word <<endl;
          Word new_word(word);
          word_vector.push_back(new_word);
      }
      file.close();
  }
  catch(const std::exception& e)
  {
      std::cerr << e.what() << '\n';
  }
  //cout << word_vector.size() << endl;
  return word_vector;
}

//start game
void Game::start()
{
  vector<Word> word_list = read_file(1);
  Word processed_words[word_list.size()];
  int count =0;
  
  for (Word current_word : word_list)
  {
    wclear(win_game);
    wclear(win_info);
    box(win_game, 0, 0);
    box(win_info, 0, 0);

    //process and draw curent word
    int random_x = 1 + (rand() % game_win_width);
    current_word.x = random_x;
    wmove(win_game, current_word.height, current_word.x);
    wprintw(win_game, "%s", current_word.word.c_str());
    current_word.height++,
    wrefresh(win_game);

    //add to processed words
    processed_words[count] = current_word;
    //mvwprintw(win_info,0,0,"%s", processed_words[count].word.c_str());
    //draw previous words
    for (Word &w : processed_words)
    {
      //move
      w.increment_height(increment);
      wmove(win_game, w.get_height(), w.x);
      //wprintw(win_game, "%d", w.height);
      wprintw(win_game, "%s", w.word.c_str());
      //cout << w.height << endl;
      wrefresh(win_game);
      //log
      //mvwprintw(win_info,0,0,"%s", (to_string(sizeof(processed_words))).c_str());
      //mvwprintw(win_info,0,0,"%s", w.word.c_str());
      //wrefresh(win_info);
    }
    wrefresh(win_info);
    count++; 
    sleep(2);
  }
}