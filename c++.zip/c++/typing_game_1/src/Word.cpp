#include <string>
using namespace std;

class Word{
  public:

    //constructors
    Word(string& w)
    {
      this->word=w; this->height=1; this->x=1;
    };
    Word()
    {
      this->word=""; this->height=1; this->x=1;
    };
    //de
    ~Word();

    //attributes:
    string word;
    int height;
    int* h = &height;
    int x;

    //functions:
    void increment_height(const int& i)
    {
      height+=i ;
    };
    int get_height(){
      return (this->height);
    };

  private:
  
};


