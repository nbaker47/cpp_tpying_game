#include "Game.cpp"


int main() {
  Game new_game;
  new_game.start();
  return 0;
}
  